# Funding Statement - FUND-FOP-047

## Golden Ratio φ, e, π and Fine Structure Constant α: Collapse Breathing Proportions

This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors.

The authors conducted this research as part of their independent theoretical investigation activities. Publication fees and associated costs will be covered by the authors' personal resources or through their institutional affiliations.

No external financial support was used in the conceptualization, design, data collection, analysis, decision to publish, or preparation of the manuscript.

The authors acknowledge the institutional support of AELF PTE LTD. in providing computational resources and research time allocation, although no direct financial support was provided for this specific project.

---

Haobo Ma (Corresponding Author)
ORCID: 0009-0008-4944-977X

Wen Niu
ORCID: 0009-0006-3349-0298

Date: 2025-04-30

---

Version: v38.0
Last Updated: 2025-04-30 